# Usage
- Run the following command,
```bash
npm start
```

# Testing
- Run the following command,
```bash
npm test
```