export function greet(): string {
  return "Hello, world!";
}
